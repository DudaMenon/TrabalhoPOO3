package strategy;

import org.example.strategy.CalculadoraDesconto;
import org.example.strategy.DescontoAVista;
import org.example.strategy.SemDesconto;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

public class CalculadoraDescontoTest {

    @Test
    void deveAplicarDescontoAVistaCorretamente() {
        // Arrange
        CalculadoraDesconto calculadora = new CalculadoraDesconto();
        calculadora.setEstrategia(new DescontoAVista());
        double valorOriginal = 100.0;

        // Act
        double resultado = calculadora.calcular(valorOriginal);

        // Assert
        assertEquals(90.0, resultado, 0.001, "O valor com 10% de desconto à vista para 100.0 deveria ser 90.0");
    }

    @Test
    void deveManterValorOriginalQuandoSemDesconto() {
        // Arrange
        CalculadoraDesconto calculadora = new CalculadoraDesconto();
        calculadora.setEstrategia(new SemDesconto());
        double valorOriginal = 100.0;

        // Act
        double resultado = calculadora.calcular(valorOriginal);

        // Assert
        assertEquals(100.0, resultado, 0.001, "Com SemDesconto, o valor final deveria permanecer 100.0");
        assertNotEquals(90.0, resultado, "Com SemDesconto, o valor final não deveria aplicar desconto");
    }

    @Test
    void deveRetornarValorOriginalQuandoEstrategiaNaoDefinida() {
        // Arrange
        CalculadoraDesconto calculadora = new CalculadoraDesconto();
        double valorOriginal = 50.0;

        // Act
        double resultado = calculadora.calcular(valorOriginal);

        // Assert
        assertEquals(50.0, resultado, 0.001, "Sem estratégia definida, deveria retornar o valor original 50.0");
    }
}